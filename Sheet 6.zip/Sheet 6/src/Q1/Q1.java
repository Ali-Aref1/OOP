package Q1;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Q1 extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        GridPane pane = new GridPane();
        pane.setPadding(new Insets(5));
        pane.setHgap(5);
        pane.setVgap(5);
        pane.add(new ImageView(new Image("Q1\\1.png")),0,0);
        pane.add(new ImageView(new Image("Q1\\2.png")),1,0);
        pane.add(new ImageView(new Image("Q1\\3.png")),0,1);
        pane.add(new ImageView(new Image("Q1\\4.png")),1,1);
        StackPane pane1 = new StackPane();
        pane1.getChildren().add(pane);
        pane1.setPadding(new Insets(20));
        pane1.setAlignment(Pos.CENTER);
        Scene scene = new Scene(pane1);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
