package Q3;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.util.Random;

public class Q3 extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        HBox hbox = new HBox();
        Random r = new Random();
        hbox.setPadding(new Insets(15));

        Text[] texts={new Text("Java"),new Text("Java"),new Text("Java"),new Text("Java"),new Text("Java")};
        for (Text t:texts){
            t.setFill(new Color(r.nextDouble(),r.nextDouble(),r.nextDouble(),r.nextDouble()));
            t.setRotate(90);
            t.setFont(Font.font("Serif", FontWeight.BOLD,FontPosture.ITALIC,22));
            hbox.getChildren().add(t);
        }
        hbox.setAlignment(Pos.CENTER);
        Scene scene = new Scene(hbox);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
