package Q5;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.util.Stack;

public class Q5 extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        HBox hbox = new HBox();
        final double barWidth=80;
        final double barHeight=5;
        int project=20;
        int quiz=10;
        int midterm=30;
        int Final=40;

        VBox[] bars = {new VBox(),new VBox(),new VBox(),new VBox()};
        Rectangle[] recs = {new Rectangle(barWidth,barHeight*project),new Rectangle(barWidth,barHeight*quiz),new Rectangle(barWidth,barHeight*midterm),new Rectangle(barWidth,barHeight*Final)};
        recs[0].setFill(Color.RED);
        recs[1].setFill(Color.BLUE);
        recs[2].setFill(Color.GREEN);
        recs[3].setFill(Color.ORANGE);

        Text[] texts = {new Text("Project -- "+project+"%"),new Text("Quiz -- "+quiz+"%"),new Text("Midterm -- "+midterm+"%"),new Text("Final -- "+Final+"%")};
        for(int i=0;i<bars.length;i++){
            bars[i].getChildren().add(texts[i]);
            bars[i].getChildren().add(recs[i]);
        }


        for(VBox v:bars){
            v.setAlignment(Pos.BOTTOM_CENTER);
            v.setSpacing(10);
        }
        hbox.getChildren().addAll(bars);
        hbox.setSpacing(10);
        hbox.setAlignment(Pos.BOTTOM_CENTER);
        hbox.setPadding(new Insets(10));
        Scene scene = new Scene(hbox);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
