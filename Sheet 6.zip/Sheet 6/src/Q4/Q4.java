package Q4;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Q4 extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        final double r = 60;
        String[] s = "WELCOME TO JAVA ".split("");

        Pane pane = new Pane();
        for (int i = 0; i < s.length; i++) {
            double angle=(2*Math.PI)*i/s.length;
            Text t = new Text(r*(1+Math.cos(angle)), r*(1+Math.sin(angle)), s[i]);
            t.setFont(Font.font("Serif", FontWeight.BOLD, FontPosture.REGULAR,22));
            t.setRotate(Math.toDegrees(angle)+90);
            pane.getChildren().add(t);
        }

        StackPane pane1 = new StackPane();
        pane1.getChildren().add(pane);
        pane1.setPadding(new Insets(20));
        pane1.setAlignment(Pos.CENTER);
        Scene scene = new Scene(pane1);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
