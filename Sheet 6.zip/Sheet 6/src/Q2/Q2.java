package Q2;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import java.util.Random;

public class Q2 extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        GridPane pane = new GridPane();
        pane.setPadding(new Insets(20));
        Random rand = new Random();
        int n;
        Image x = new Image("Q2\\x.gif");
        Image o = new Image("Q2\\o.gif");
        for(int i=0;i<3;i++) {
            for(int j=0;j<3;j++){
                n = rand.nextInt(3);
                switch(n){
                    case 0:break;
                    case 1:pane.add(new ImageView(x),j,i);break;
                    case 2:pane.add(new ImageView(o),j,i);
                }
            }
        }
        StackPane pane1 = new StackPane();
        pane1.getChildren().add(pane);
        pane1.setPadding(new Insets(20));
        pane1.setAlignment(Pos.CENTER);
        Scene scene = new Scene(pane1);
        primaryStage.setScene(scene);
        primaryStage.setWidth(350);
        primaryStage.setHeight(350);
        primaryStage.show();

    }
}
